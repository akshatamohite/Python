
a=int(input("ENTER A NUMBER OF WHICH YOU WANT FACTORIAL:"))
factorial=1
if a<0:
 print("invalid number:")
elif a==0:
 print ("factorial of 0 is: 1")
if a>0:
 for x in range(1,a+1):
  factorial=int(factorial*x)
 print (factorial) 
