print('hello')
print("HELLO")
print("""HELLO NCER """)

a="HELLO WORLD"
print(a[1])

print("""NCER CSE,NCER ENTC,NCER Mech""")

