list1=[]
num1=int(input("Enter list values to be entered"))

for n in range (num1):
    number1=int(input("Numbers in 1st list"))
    list1.append(number1)
    
list2=[]
num2=int(input("Enter list values to be entered"))
for n in range (num2):
    number2=int(input("Numbers in 2nd list"))
    list2.append(number2)

union1=list(set().union(list1,list2))
print('The union of two lists are',union1)
