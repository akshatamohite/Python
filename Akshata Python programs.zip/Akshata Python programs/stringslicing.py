a2="NCER CSE"
print(a2[2:6])
print(a2[:5])
print(a2[2:])
print(a2.lower())

a="ncer computer science "
print(a.upper())
print(a.strip())
