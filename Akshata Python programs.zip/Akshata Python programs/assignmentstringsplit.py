str1="hello ncer hello CSE hello Mech"
word="hello"
list=[]
wordcount=0
list=str1.split(" ")
for i in range(0, len(list)):
 if(word==list[i]):
  wordcount=wordcount+1
print("number of occurance found in string is:",wordcount)
 
