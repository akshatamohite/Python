student_name="Sakshi"
marks={"priya":96,"Shivani":90,"Mayuri":95}
for stud in  marks:
    if stud==student_name:
      print(marks[stud]);
      break
else:
      print("No entry with the name",student_name)    
    
