
def intersection_f(list1,list2):
    return set(list1).intersection(list2)

list1=[1,2,3,4,5,6,7]
list2=[4,5,4,6,7]

print("The intersection of two lists is: ")
print(intersection_f(list1,list2))
