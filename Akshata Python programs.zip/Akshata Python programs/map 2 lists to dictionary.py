keyList=[]
valueList=[]

numb=int(input("Enter NO. of elements to be added in dictionary"))

print("Enter Keys:")
for p in range (numb):
   Keyelement=int(input("Enter the Key"+ str(p+1)+"="))
   keyList.append(Keyelement)


print("Enter the values:")
for p in range (numb):
   valuelement=int(input("Enter the Key"+ str(p+1)+"="))
   valueList.append(valuelement)


   resultdict=dict(zip(keyList,valueList))
   print("The result in dictionary with keys=",keyList,"values",valueList,":")
   print(resultdict)

   
