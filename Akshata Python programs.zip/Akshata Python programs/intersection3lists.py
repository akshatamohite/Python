def intersection_f(list1,list2,list3):
    return set(list1).intersection(list2).intersection(list3)

list1=[1,2,3,4,5,6,7]
list2=[4,5,4,6,7]
list3=[1,2,4,15,16]

print(intersection_f(list1,list2,list3))

