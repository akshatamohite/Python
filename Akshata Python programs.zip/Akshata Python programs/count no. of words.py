sry=input("Please enter any string:")
words=[]
words=str.split()
newDict={}
for Key in words:
    myDict=[Key]=words.count(Key)

print("dictionary items:"myDict)
