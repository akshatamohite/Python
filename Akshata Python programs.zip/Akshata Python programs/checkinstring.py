a="Smile is always free"
print("free" in a)

a1="smile is precious"
if "smile" in a1:
 print("Yes,its there" )

a2="smile CSE Always"
print("NCER" not in a2)

