print("enter the marks of five subjects outoff 100")
a=float(input("enter the marks of PP"))
b=float(input("enter the marks of OS"))
c=float(input("enter the marks of DAA"))
d=float(input("enter the marks of BHR"))
e=float(input("enter the marks of PTRP"))
sum=a+b+c+d+e
print("the total marks is:",sum)
per=((sum/500)*100)
print("the total PERCENTAGE is:",per)
if per>=90:
 print("the grade of student is :A")
elif per>=80 and per<90:
 print("the grade of student is :B")
elif per>=70 and per<80:
 print("the grade of student is :C")
elif per>=60 and per<50:
 print("the grade of student is :D")
elif per>=50 and per<35:
 print("the grade of student is :E")
else:
 print("the grade of student is :f")
