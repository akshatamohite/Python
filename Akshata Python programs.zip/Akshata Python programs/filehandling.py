import os

if os.path.exists("demof.txt"):
 os.remove("demof.txt")
else:
 print("The file does not exist")

f = open("demof.txt", "x")
f.close()

f1 = open("demof.txt", "w")
f1.write("Now the file has some original content...")
f1.close()

f2 = open("demof.txt", "a")
f2.write("This file displays the content...")
f2.close()

f3 = open("demof.txt", "r")
print(f3.read())



