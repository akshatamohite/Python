for x in "banana":
 print(x)

a="HELLO WORLD"
print(len(a))
